var Person = require('../models/personModel')
let crime =  require("C:/Users/HP/Downloads/crimedata.json")
console.log(crime)

module.exports = function (app, mongoose) {

    // seed database
    app.get('/person/setup', function (req, res) {


        var seedPeople = crime;

        Person.create(seedPeople, function (err, data) {
            if (err) {
                res.send(err)
            } else {
                res.send(data)
            }

        })
    })


    // purget people collection
    app.get('/person/purge', function (req, res) {

        mongoose.connection.db.dropCollection('people', function(err, data) {

            if (err) {
                res.send(err)
            } else {
                res.send(data)
            }
        })

    })


}
