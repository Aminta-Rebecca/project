let fooFile =  require("C:/Users/HP/Downloads/happy.json")
//console.log(fooFile)
var seed;
seed=fooFile
console.log(seed)
