var mongoose = require('mongoose')

// data
var Schema = mongoose.Schema

var personSchema = new Schema({
    area_name: String,
    murder: String,
    rape: String,
    kidnappingandabduction:String,
    robbery: String,
    auto_theft: String,
    burglary: String,
    theft:String,
    arson: String,
    dacoity:String,
    riots: String,
})


var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:3000/";


// person schema for mongo
var Person = mongoose.model('Person', personSchema)

module.exports = Person

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("mydb");
  var query = { address: "Park Lane 38" };
});

var cursor = Person.aggregate(pipeline, options);

cursor.forEach(
    function(doc) {
        console.log(doc);
    },
    function(err) {
        client.close();
    }
);
